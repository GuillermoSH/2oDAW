<?php declare(strict_types=1); ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset= "UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href=" ">
    <title>Ejercicio 2</title>
</head>
<body>
    <?php
        $BBDD = "./form.json";
        $fdBBDD = fopen($BBDD, "r");
        $header = fgets($fdBBDD);
    ?>
</body>
</html>