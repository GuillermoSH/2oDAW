<?php
    declare(strict_types = 1); 
    header("Location: ./controller/MantenimientoProductos.php");
?>