<?php
if (!defined('__CONFIG__')) {
    define('__CONFIG__', true);
    define('ROOT_PATH', '/PHP');
    define('PROJECT_PATH', '/var/www/html/DSW');
    define("DATA_PATH", "/var/www/phpdata");
}