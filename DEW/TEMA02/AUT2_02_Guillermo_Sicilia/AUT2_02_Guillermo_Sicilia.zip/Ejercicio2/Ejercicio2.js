function ejercicio2() {
    let suma = 0;

    for (let i = 1; i <= 10; i++) {
        suma += i;
    }

    console.log(`La suma de los números entre 1 y 10 es: ${suma}`);
}