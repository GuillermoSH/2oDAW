let resultado = 15, base = 15, exponente = 6;

for (let i = 1; i < exponente; i++) {
    resultado *= base;
}

document.getElementById("ejercicio1").innerHTML = resultado;
