import { GenderColorPipe } from './gender-color.pipe';

describe('GenderColorPipe', () => {
  it('create an instance', () => {
    const pipe = new GenderColorPipe();
    expect(pipe).toBeTruthy();
  });
});
