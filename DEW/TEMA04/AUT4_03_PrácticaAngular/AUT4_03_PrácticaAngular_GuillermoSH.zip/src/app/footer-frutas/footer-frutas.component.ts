import { Component } from '@angular/core';

@Component({
  selector: 'footer-frutas',
  templateUrl: './footer-frutas.component.html',
  styleUrls: ['./footer-frutas.component.css']
})
export class FooterFrutasComponent {
  nombre = "Fruterias Puerto de la Cruz";
  copyright = "Angular @2022";
}
