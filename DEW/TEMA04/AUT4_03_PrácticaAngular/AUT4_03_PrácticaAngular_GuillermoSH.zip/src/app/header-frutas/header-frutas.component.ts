import { Component } from '@angular/core';

@Component({
  selector: 'header-frutas',
  templateUrl: './header-frutas.component.html',
  styleUrls: ['./header-frutas.component.css']
})
export class HeaderFrutasComponent {
  imgUrl = "../../assets/img/logo.png";
}
