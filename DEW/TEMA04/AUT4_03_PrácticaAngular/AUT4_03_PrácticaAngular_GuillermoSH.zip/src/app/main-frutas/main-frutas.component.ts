import { Component } from '@angular/core';

@Component({
  selector: 'main-frutas',
  templateUrl: './main-frutas.component.html',
  styleUrls: ['./main-frutas.component.css']
})
export class MainFrutasComponent {

}
